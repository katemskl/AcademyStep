from tkinter import *


def show_action(act, entry):
    entry.insert(0, act)


def clear(entry):
    entry.delete(0, END)


def make_action(action):
    pass


def get_number(number):
    pass


def return_result(result):
    pass
