import pickle
from tkinter import *
from tkinter import messagebox


def registration(root):

    label_error = None

    frame = Frame(root, bd=10)
    frame.place(relx=0.5, rely=0.2, relwidth=0.7, relheight=0.6, anchor='n')

    label = Label(frame, text='Sign Up', font='16')
    label.place(relheight=.1, relwidth=1)

    label_login = Label(frame, text='Login: ')
    label_login.place(rely=.2, relheight=.1, relwidth=.55)

    label_register = Entry(frame)
    label_register.place(relx=.4, rely=.2, relheight=.1, relwidth=.55)

    label_password1 = Label(frame, text='Password: ')
    label_password1.place(rely=.4, relwidth=.35, relheight=.1)

    password1_entry = Entry(frame, show='*')
    password1_entry.place(relx=.4, rely=.4, relheight=.1, relwidth=.55)

    label_password2 = Label(frame, text='Re-Password: ')
    label_password2.place(rely=.6, relwidth=.35, relheight=.1)

    password2_entry = Entry(frame, show='*')
    password2_entry.place(relx=.4, rely=.6, relheight=.1, relwidth=.55)

    button = Button(frame, text='Sign Up', command=lambda: sign_up())
    button.place(relx=.3, rely=.8, relheight=0.15, relwidth=.5)

    def sign_up():
        nonlocal label_error
        error = ''

    def save():
        pass


def log_in():
    def login_pass():
        pass



